Proyecto-U
==========

Trabajo de semillero
  -Es un trabajo conjunto de compañeros de la Univerersidad 5to y 6to Semestre
    Universidad minuto de Dios
    
  -Se espera tener un producto terminado el cual beneficiara a un grupo de Empresas de la Ciudad de girardot.
